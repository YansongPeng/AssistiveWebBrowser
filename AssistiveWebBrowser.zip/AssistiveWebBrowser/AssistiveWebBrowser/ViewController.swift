//
//  ViewController.swift
//  AssistiveWebBrowser
//
//  Created by Yansong Peng on 3/23/18.
//  Copyright © 2018 Yansong Peng. All rights reserved.
//

import UIKit
import SafariServices

class ViewController: UIViewController, UISearchBarDelegate, UIWebViewDelegate, SFSafariViewControllerDelegate {
    
    private var urlString:String = "https://www.google.com/"

    @IBOutlet weak var urlText: UISearchBar!
    @IBOutlet weak var webView: UIWebView!
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        urlText.resignFirstResponder()
        
        openBrowser(withReaderMode: true)
        
        urlText.text = ""
        
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
    fileprivate func openBrowser(withReaderMode readerMode: Bool) {
        let svc = SFSafariViewController(url: NSURL(string: self.urlText.text!)! as URL, entersReaderIfAvailable: readerMode)
        // You can also init the view controller with the SFSafariViewController:url: method
        svc.delegate = self
        if #available(iOS 11.0, *) {
            // The color to tint the background of the navigation bar and the toolbar.
            svc.preferredBarTintColor = readerMode ? .black : .black
            // The color to tint the the control buttons on the navigation bar and the toolbar.
            svc.preferredControlTintColor = .white
        } else {
            // Fallback on earlier versions
        }
        present(svc, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension SFSafariViewControllerDelegate {
    func safariViewController(_ controller: SFSafariViewController, didCompleteInitialLoad didLoadSuccessfully: Bool) {
        //Tells the delegate that the URL load completed.
    }
    
    func safariViewController(_ controller: SFSafariViewController, activityItemsFor URL: URL, title: String?) -> [UIActivity] {
        //Tells the delegate that the user tapped an Action button.
        return []
    }
    
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        //Tells the delegate that the user dismissed the view.
    }
}

